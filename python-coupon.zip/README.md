# 京东优惠追踪 (JD Coupon Tracker)

A web application that automatically scrapes and aggregates JD.com coupons and deals from multiple Chinese deal sites.

## Features

- 🔄 **Automatic Scraping** - Hourly updates from 3 major deal sites
- 🎨 **Modern UI** - Clean, responsive design with dark mode
- 🔍 **Smart Search** - Real-time filtering by keyword
- 📊 **Multiple Views** - Toggle between grid and list layouts
- 🏷️ **Source Filtering** - Filter by deal source (逛丢, 券老大, 慢慢买)
- 📱 **Mobile Friendly** - Works perfectly on all devices

## Quick Start (3 Methods)

### Method 1: Manual Setup (Recommended for Development)

#### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

#### Installation Steps

1. **Extract the files** to your desired directory

2. **Create a virtual environment**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   playwright install chromium  # Required for JS-rendered pages
   ```

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Access the site**
   - Open your browser to: `http://localhost:5001`
   - Click the refresh button to start scraping

---

### Method 2: Docker (Recommended for Production)

#### Prerequisites
- Docker
- Docker Compose (optional but recommended)

#### Using Docker Compose (Easiest)

1. **Start the application**
   ```bash
   docker-compose up -d
   ```

2. **Access the site**
   - Open your browser to: `http://localhost:5001`

3. **Stop the application**
   ```bash
   docker-compose down
   ```

#### Using Docker directly

1. **Build the image**
   ```bash
   docker build -t jd-coupon-tracker .
   ```

2. **Run the container**
   ```bash
   docker run -d -p 5001:5001 \
     -v $(pwd)/data:/app/data \
     --name jd-coupons \
     jd-coupon-tracker
   ```

3. **Stop the container**
   ```bash
   docker stop jd-coupons
   docker rm jd-coupons
   ```

---

### Method 3: Automated Install Script

#### For Linux/macOS:
```bash
chmod +x install.sh
./install.sh
```

#### For Windows:
```powershell
.\install.ps1
```

## Configuration

### Environment Variables

Create a `.env` file in the root directory (optional):

```env
# Flask Configuration
FLASK_SECRET=your-secret-key-here
FLASK_PORT=5001
FLASK_DEBUG=False

# Scraper Configuration
SCRAPE_INTERVAL_MINUTES=60
CLEAR_DB_ON_START=False

# Database
DB_PATH=jd_coupons.db
```

### app.py Configuration

You can also edit `app.py` directly:

```python
CLEAR_DB_ON_START = False   # Set True to clear database on startup
SCRAPE_INTERVAL_MINUTES = 60  # How often to scrape (in minutes)
DB_PATH = "jd_coupons.db"     # Database file location
```

## Project Structure

```
jd-coupon-tracker/
├── app.py                 # Flask application
├── scraper.py            # Scraping logic for all sources
├── requirements.txt      # Python dependencies
├── Dockerfile           # Docker configuration
├── docker-compose.yml   # Docker Compose configuration
├── install.sh          # Linux/macOS install script
├── install.ps1         # Windows install script
├── templates/
│   ├── base.html       # Base template
│   └── index.html      # Main page
├── static/
│   ├── style.css       # Stylesheet
│   └── images/         # Downloaded coupon images
└── data/               # Database and logs (created on first run)
```

## Usage

### First Run

1. Start the application using any of the methods above
2. Click the **刷新** (Refresh) button in the header to trigger the first scrape
3. Wait 1-2 minutes for scraping to complete
4. The page will populate with coupons

### Features

- **Search**: Type keywords in the search bar to filter coupons
- **Filter by Source**: Click source buttons (全部, 逛丢, 券老大, 慢慢买)
- **Switch Views**: Toggle between grid and list layouts
- **Dark Mode**: Click the moon icon for dark mode
- **Manual Refresh**: Click refresh button to scrape immediately

### Automatic Updates

The app automatically scrapes new coupons every hour (configurable). You don't need to manually refresh unless you want immediate updates.

## Troubleshooting

### Scraping Issues

**Problem**: No coupons appearing after scrape

**Solutions**:
1. Check your internet connection
2. Some sites may block requests - this is normal, the app will continue with available sources
3. Check logs in terminal for specific error messages
4. Try running scraper manually: `python -c "from scraper import JDCouponScraper; s = JDCouponScraper(); s.scrape_all()"`

### SSL Certificate Errors

**Problem**: SSL verification errors when scraping

**Solution**: The app is configured with `verify_ssl=False` for sites with certificate issues. This is safe for read-only scraping.

### Image Loading Issues

**Problem**: Some coupon images not displaying

**Solution**: Images are downloaded locally. If download fails, a placeholder will show. This is normal and doesn't affect functionality.

### Port Already in Use

**Problem**: Port 5001 is already taken

**Solution**: 
1. Change port in `app.py`: `app.run(host="0.0.0.0", port=5002)`
2. Or stop the process using port 5001: `lsof -ti:5001 | xargs kill` (macOS/Linux)

### Playwright Installation Issues

**Problem**: Playwright browser won't install

**Solution**:
```bash
# Try installing with elevated permissions
sudo playwright install chromium

# Or install system dependencies
playwright install-deps
```

## Development

### Adding New Scraper Sources

1. Open `scraper.py`
2. Add a new method following the pattern:
   ```python
   def scrape_yoursite(self) -> List[Dict]:
       # Your scraping logic
       pass
   ```
3. Add it to `scrape_all()` method
4. Test with: `python -c "from scraper import JDCouponScraper; s = JDCouponScraper(); s.scrape_yoursite()"`

### Customizing the Design

1. Edit `static/style.css` for styling changes
2. Edit `templates/index.html` for layout changes
3. Colors are defined in CSS variables at the top of `style.css`

## Performance

- **Database**: SQLite with automatic deduplication
- **Memory**: ~200-300MB during scraping
- **Disk**: ~50-100MB for database and images
- **Scraping Time**: 1-3 minutes for all sources

## Security Notes

- This app is designed for **personal/internal use**
- No user authentication by default
- If deploying publicly, consider adding:
  - Rate limiting
  - User authentication
  - HTTPS/SSL
  - Reverse proxy (nginx/Apache)

## License

This project is for educational and personal use. Please respect the terms of service of the scraped websites.

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review error messages in terminal
3. Check that all dependencies are installed correctly

## Credits

**Scraped Sources**:
- 逛丢 (guangdiu.com)
- 券老大 (quanlaoda.com)
- 慢慢买 (manmanbuy.com)

Built with Flask, BeautifulSoup, Playwright, and love for deals! 🛍️
