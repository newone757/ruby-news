# JD Coupon Tracker - Installation Script for Windows PowerShell
# This script automates the setup process

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  京东优惠追踪 Installation Script" -ForegroundColor Cyan
Write-Host "  JD Coupon Tracker Setup for Windows" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Check if Python 3 is installed
Write-Host "Checking for Python 3..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    if ($pythonVersion -match "Python (\d+\.\d+\.\d+)") {
        Write-Host "✓ Found $pythonVersion" -ForegroundColor Green
    } else {
        throw "Python not found"
    }
} catch {
    Write-Host "Error: Python 3 is not installed." -ForegroundColor Red
    Write-Host "Please install Python 3.8 or higher from https://www.python.org/downloads/" -ForegroundColor Red
    Write-Host "Make sure to check 'Add Python to PATH' during installation!" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Check if pip is installed
Write-Host "Checking for pip..." -ForegroundColor Yellow
try {
    $pipVersion = pip --version 2>&1
    Write-Host "✓ pip is available" -ForegroundColor Green
} catch {
    Write-Host "Error: pip is not installed." -ForegroundColor Red
    Write-Host "Installing pip..." -ForegroundColor Yellow
    python -m ensurepip --default-pip
}
Write-Host ""

# Create virtual environment
Write-Host "Creating virtual environment..." -ForegroundColor Yellow
if (Test-Path "venv") {
    Write-Host "Virtual environment already exists. Skipping..." -ForegroundColor Yellow
} else {
    python -m venv venv
    Write-Host "✓ Virtual environment created" -ForegroundColor Green
}
Write-Host ""

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& ".\venv\Scripts\Activate.ps1"
Write-Host "✓ Virtual environment activated" -ForegroundColor Green
Write-Host ""

# Upgrade pip
Write-Host "Upgrading pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip | Out-Null
Write-Host "✓ pip upgraded" -ForegroundColor Green
Write-Host ""

# Install requirements
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
Write-Host "This may take a few minutes..." -ForegroundColor Yellow
if (Test-Path "requirements.txt") {
    pip install -r requirements.txt
    Write-Host "✓ Dependencies installed" -ForegroundColor Green
} else {
    Write-Host "Error: requirements.txt not found" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Install Playwright browsers
Write-Host "Installing Playwright Chromium browser..." -ForegroundColor Yellow
Write-Host "This may take a few minutes on first run..." -ForegroundColor Yellow
playwright install chromium
Write-Host "✓ Playwright browser installed" -ForegroundColor Green
Write-Host ""

# Create necessary directories
Write-Host "Creating data directories..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path "data" | Out-Null
New-Item -ItemType Directory -Force -Path "static\images" | Out-Null
Write-Host "✓ Directories created" -ForegroundColor Green
Write-Host ""

# Check if app.py exists
if (-not (Test-Path "app.py")) {
    Write-Host "Error: app.py not found" -ForegroundColor Red
    Write-Host "Make sure you're running this script from the project directory." -ForegroundColor Yellow
    exit 1
}

Write-Host "================================================" -ForegroundColor Green
Write-Host "Installation Complete!" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Green
Write-Host ""
Write-Host "To start the application:" -ForegroundColor Cyan
Write-Host ""
Write-Host "  1. Make sure the virtual environment is activated:" -ForegroundColor White
Write-Host "     .\venv\Scripts\Activate.ps1" -ForegroundColor Yellow
Write-Host ""
Write-Host "  2. Run the application:" -ForegroundColor White
Write-Host "     python app.py" -ForegroundColor Yellow
Write-Host ""
Write-Host "  3. Open your browser to:" -ForegroundColor White
Write-Host "     http://localhost:5001" -ForegroundColor Yellow
Write-Host ""
Write-Host "To deactivate the virtual environment later, run:" -ForegroundColor White
Write-Host "     deactivate" -ForegroundColor Yellow
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Ask if user wants to start the app now
$response = Read-Host "Would you like to start the application now? (y/n)"
if ($response -eq "y" -or $response -eq "Y") {
    Write-Host ""
    Write-Host "Starting JD Coupon Tracker..." -ForegroundColor Green
    Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
    Write-Host ""
    python app.py
}
