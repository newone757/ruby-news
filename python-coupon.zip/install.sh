#!/bin/bash

# JD Coupon Tracker - Installation Script for Linux/macOS
# This script automates the setup process

set -e  # Exit on error

echo "================================================"
echo "  京东优惠追踪 Installation Script"
echo "  JD Coupon Tracker Setup"
echo "================================================"
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Python 3 is installed
echo "Checking for Python 3..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}Error: Python 3 is not installed.${NC}"
    echo "Please install Python 3.8 or higher and try again."
    echo "Visit: https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
echo -e "${GREEN}✓ Found Python $PYTHON_VERSION${NC}"
echo ""

# Check if pip is installed
echo "Checking for pip..."
if ! command -v pip3 &> /dev/null; then
    echo -e "${RED}Error: pip3 is not installed.${NC}"
    echo "Installing pip..."
    python3 -m ensurepip --default-pip
fi
echo -e "${GREEN}✓ pip is available${NC}"
echo ""

# Create virtual environment
echo "Creating virtual environment..."
if [ -d "venv" ]; then
    echo -e "${YELLOW}Virtual environment already exists. Skipping...${NC}"
else
    python3 -m venv venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
fi
echo ""

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
echo -e "${GREEN}✓ Virtual environment activated${NC}"
echo ""

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip > /dev/null 2>&1
echo -e "${GREEN}✓ pip upgraded${NC}"
echo ""

# Install requirements
echo "Installing Python dependencies..."
echo "This may take a few minutes..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
    echo -e "${GREEN}✓ Dependencies installed${NC}"
else
    echo -e "${RED}Error: requirements.txt not found${NC}"
    exit 1
fi
echo ""

# Install Playwright browsers
echo "Installing Playwright Chromium browser..."
echo "This may take a few minutes on first run..."
playwright install chromium
echo -e "${GREEN}✓ Playwright browser installed${NC}"
echo ""

# Create necessary directories
echo "Creating data directories..."
mkdir -p data static/images
echo -e "${GREEN}✓ Directories created${NC}"
echo ""

# Check if app.py exists
if [ ! -f "app.py" ]; then
    echo -e "${RED}Error: app.py not found${NC}"
    echo "Make sure you're running this script from the project directory."
    exit 1
fi

echo "================================================"
echo -e "${GREEN}Installation Complete!${NC}"
echo "================================================"
echo ""
echo "To start the application:"
echo ""
echo "  1. Make sure the virtual environment is activated:"
echo "     ${YELLOW}source venv/bin/activate${NC}"
echo ""
echo "  2. Run the application:"
echo "     ${YELLOW}python app.py${NC}"
echo ""
echo "  3. Open your browser to:"
echo "     ${YELLOW}http://localhost:5001${NC}"
echo ""
echo "To deactivate the virtual environment later, run:"
echo "     ${YELLOW}deactivate${NC}"
echo ""
echo "================================================"
echo ""

# Ask if user wants to start the app now
read -p "Would you like to start the application now? (y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "Starting JD Coupon Tracker..."
    echo "Press Ctrl+C to stop the server"
    echo ""
    python app.py
fi
