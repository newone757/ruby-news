# scraper.py — with Playwright support + detailed logging

import os
import time
import hashlib
import sqlite3
import logging
from datetime import datetime
from typing import List, Dict, Optional

import requests
from bs4 import BeautifulSoup

# Optional JS rendering
from playwright.sync_api import sync_playwright

# -----------------------------------------
# Logging setup
# -----------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

DB_PATH = "jd_coupons.db"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


class JDCouponScraper:
    def __init__(self, db_path: str = DB_PATH, verify_ssl: bool = False, clear_db: bool = False):
        self.db_path = db_path
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        })
        os.makedirs(os.path.join("static", "images"), exist_ok=True)
        self.init_database(clear_db)

    # -----------------------------------------
    # Database setup
    # -----------------------------------------
    def init_database(self, clear_db: bool = False):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS scrape_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                status TEXT NOT NULL,
                coupons_found INTEGER,
                error_message TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        if clear_db:
            cur.execute("DROP TABLE IF EXISTS coupons")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS coupons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                coupon_hash TEXT UNIQUE NOT NULL,
                source TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                discount_amount TEXT,
                discount_type TEXT,
                min_purchase TEXT,
                coupon_code TEXT,
                coupon_url TEXT,
                image_url TEXT,
                expiry_date TEXT,
                category TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        conn.close()

    # -----------------------------------------
    # Utility
    # -----------------------------------------
    def generate_hash(self, title, source, discount, url):
        unique = f"{source}:{title}:{discount or ''}:{url or ''}"
        return hashlib.md5(unique.encode("utf-8")).hexdigest()

    def log_scrape(self, source, status, count=0, error=None):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute(
            "INSERT INTO scrape_logs (source, status, coupons_found, error_message) VALUES (?, ?, ?, ?)",
            (source, status, count, error),
        )
        conn.commit()
        conn.close()

    # -----------------------------------------
    # Networking helpers
    # -----------------------------------------
    def fetch_url(self, url: str, timeout=15, verify=True):
        try:
            #r = self.session.get(url, timeout=timeout, verify=self.verify_ssl)
            r = self.session.get(url, timeout=timeout, verify=verify)
            r.raise_for_status()
            return r
        except Exception as e:
            logger.warning(f"Failed to fetch {url}: {e}")
            return None

    def fetch_with_js(self, url: str, wait_selector: Optional[str] = None) -> Optional[str]:
        """Use Playwright to fetch JS-rendered pages."""
        try:
            logger.info(f"[JS] Launching Playwright browser for {url}")
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(user_agent=USER_AGENT)
                page = context.new_page()
                page.goto(url, timeout=30000)
                if wait_selector:
                    page.wait_for_selector(wait_selector, timeout=15000)
                html = page.content()
                browser.close()
                return html
        except Exception as e:
            logger.error(f"[JS] Failed to render {url}: {e}")
            return None

    def download_image(self, url: str, verify=True) -> Optional[str]:
        if not url or not url.startswith("http"):
            return None
        try:
            ext = os.path.splitext(url.split("?")[0])[1]
            if not ext or len(ext) > 5:
                ext = ".jpg"
            fname = hashlib.md5(url.encode("utf-8")).hexdigest() + ext
            local_path = os.path.join("static", "images", fname)
            web_path = f"/static/images/{fname}"
            if os.path.exists(local_path):
                return web_path
            #r = self.session.get(url, timeout=15, verify=self.verify_ssl)
            r = self.session.get(url, timeout=15, verify=verify)
            if r.status_code == 200 and r.content:
                with open(local_path, "wb") as f:
                    f.write(r.content)
                return web_path
        except Exception as e:
            logger.warning(f"Failed to download image {url}: {e}")
        return None

    def save_coupon(self, data: Dict):
        h = self.generate_hash(data.get("title"), data.get("source"), data.get("discount_amount"), data.get("coupon_url"))
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""
            INSERT INTO coupons (
                coupon_hash, source, title, description, discount_amount,
                discount_type, min_purchase, coupon_code, coupon_url,
                image_url, expiry_date, category
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(coupon_hash) DO UPDATE SET
                title=excluded.title,
                discount_amount=excluded.discount_amount,
                description=excluded.description,
                coupon_url=excluded.coupon_url,
                image_url=excluded.image_url,
                category=excluded.category,
                updated_at=CURRENT_TIMESTAMP
        """, (
            h, data.get("source"), data.get("title"), data.get("description"),
            data.get("discount_amount"), data.get("discount_type"), data.get("min_purchase"),
            data.get("coupon_code"), data.get("coupon_url"), data.get("image_url"),
            data.get("expiry_date"), data.get("category")
        ))
        conn.commit()
        conn.close()

    # -----------------------------------------
    # Scrapers
    # -----------------------------------------
    
    # -----------------------------
    # Guangdiu scraper (updated)
    # -----------------------------
    def scrape_guangdiu(self) -> List[Dict]:
        """Scrape JD deals from Guangdiu (extract images)"""
        coupons = []
        source = "guangdiu.com"
        urls = [
            ("https://guangdiu.com/cate.php?m=%E4%BA%AC%E4%B8%9C%E5%95%86%E5%9F%8E", "JD Mall"),
            ("https://guangdiu.com/cate.php?m=%E4%BA%AC%E4%B8%9C%E8%87%AA%E8%90%A5", "JD Self-Operated")
        ]

        for url, category in urls:
            try:
                print(f"\n  Fetching {category} ...")
                resp = self.fetch_url(url, timeout=25)
                if not resp:
                    print(f"  ✗ Failed to fetch {category}")
                    continue

                soup = BeautifulSoup(resp.content, "html.parser")
                items = soup.find_all("div", class_="gooditem")
                print(f"  Found {len(items)} 'gooditem' elements on {category}")

                if not items:
                    # save debug page to inspect
                    fname = f"guangdiu_debug_{category.replace(' ', '_')}.html"
                    with open(fname, "w", encoding="utf-8") as f:
                        f.write(soup.prettify())
                    print(f"  ✗ No items found — saved debug HTML to {fname}")
                    continue

                for item in items[:50]:
                    try:
                        title_a = item.find("a", class_="goodname")
                        if not title_a:
                            continue
                        title = title_a.get_text(" ", strip=True)
                        detail_url = title_a.get("href", "").strip()
                        if detail_url and not detail_url.startswith("http"):
                            detail_url = f"https://guangdiu.com/{detail_url.lstrip('./')}"

                        price_span = title_a.find("span", class_="emphricepart")
                        discount_amount = price_span.get_text(strip=True) if price_span else None

                        desc_a = item.find("a", class_="abstractcontent")
                        description = desc_a.get_text(" ", strip=True) if desc_a else None

                        buy_a = item.find("a", class_="innergototobuybtn")
                        coupon_url = buy_a.get("href") if buy_a else detail_url
                        if coupon_url and not coupon_url.startswith("http"):
                            coupon_url = f"https://guangdiu.com/{coupon_url.lstrip('./')}"

                        img = item.find("img", class_="imgself")
                        image_url = img.get("src") if img else None
                        local_img = self.download_image(image_url) if image_url else None

                        mall_div = item.find("div", class_="rightmall")
                        mall_name = mall_div.get_text(" ", strip=True) if mall_div else "JD.com"

                        coupon = {
                            "source": source,
                            "title": title,
                            "description": description,
                            "discount_amount": discount_amount,
                            "discount_type": "deal",
                            "min_purchase": None,
                            "coupon_url": coupon_url,
                            "image_url": local_img,
                            "category": f"{mall_name} - {category}"
                        }

                        self.save_coupon(coupon)
                        coupons.append(coupon)
                    except Exception as e:
                        print(f"    ✗ item parse error: {e}")
                        continue

                time.sleep(1)
            except Exception as e:
                print(f"  ✗ Error scraping {category}: {e}")
                continue

        self.log_scrape(source, "success" if coupons else "error", len(coupons))
        print(f"\n  ✓ Guangdiu scraped {len(coupons)} coupons total")
        return coupons

    # -----------------------------
    # Quanlaoda scraper
    # -----------------------------
    def scrape_quanlaoda(self) -> List[Dict]:
        coupons = []
        source = "quanlaoda.com"

        try:
            url = "https://www.quanlaoda.com/jingdong"
            resp = self.fetch_url(url, timeout=20, verify=False)
            if not resp:
                raise Exception("Failed to fetch quanlaoda main page")

            soup = BeautifulSoup(resp.content, "html.parser")
            coupon_lists = soup.find_all("ul", class_="coupons-list")
            if not coupon_lists:
                fname = "quanlaoda_debug.html"
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(soup.prettify())
                print(f"  ✗ No coupon lists found — saved debug HTML to {fname}")
                self.log_scrape(source, "error", 0, "No coupon lists found")
                return coupons

            for coupon_list in coupon_lists:
                items = coupon_list.find_all("li")
                for item in items[:50]:
                    try:
                        # Title & link
                        h2 = item.find("h2")
                        a = h2.find("a") if h2 else None
                        if not a:
                            continue
                        title = a.get_text(" ", strip=True)
                        detail_href = a.get("href", "").strip()
                        coupon_url = detail_href
                        if coupon_url and not coupon_url.startswith("http"):
                            coupon_url = f"https://www.quanlaoda.com{coupon_url}"

                        # description / discount_amount
                        desc_span = item.find("span", class_="description")
                        discount_amount = "Unknown"
                        min_purchase = None
                        if desc_span:
                            # look for em tags (many items use <em class="description_none">text</em>)
                            ems = desc_span.find_all("em")
                            if len(ems) >= 2:
                                # often structure '满 <em>XXX</em> 减 <em>YYY</em>'
                                min_purchase = ems[0].get_text(strip=True)
                                discount_amount = ems[1].get_text(strip=True)
                                # normalized
                                discount_amount = f"满{min_purchase}减{discount_amount}"
                            else:
                                # fallback to nested description_none or inner text
                                em_none = desc_span.find("em", class_="description_none")
                                if em_none:
                                    discount_amount = em_none.get_text(strip=True)
                                else:
                                    txt = desc_span.get_text(" ", strip=True)
                                    if txt:
                                        discount_amount = txt

                        # image - many list items contain <span class="store-logo"><img src="..."/></span>
                        img_tag = item.find("img")
                        image_url = img_tag.get("src") if img_tag else None
                        if image_url and image_url.startswith("/"):
                            image_url = f"https://www.quanlaoda.com{image_url}"
                        local_img = self.download_image(image_url, verify=False) if image_url else None

                        coupon = {
                            "source": source,
                            "title": title,
                            "description": None,
                            "discount_amount": discount_amount,
                            "discount_type": "coupon",
                            "min_purchase": min_purchase,
                            "coupon_url": coupon_url,
                            "image_url": local_img,
                            "category": "JD.com"
                        }

                        self.save_coupon(coupon)
                        coupons.append(coupon)
                    except Exception as e:
                        print(f"    ✗ item parse error (quanlaoda): {e}")
                        continue

            self.log_scrape(source, "success", len(coupons))
            print(f"  ✓ Quanlaoda scraped {len(coupons)} coupons")
        except Exception as e:
            err = str(e)
            print(f"  ✗ Error scraping quanlaoda: {err}")
            self.log_scrape(source, "error", 0, err)

        return coupons




    def scrape_manmanbuy(self) -> List[Dict]:
        logger.info("→ Scraping Manmanbuy (慢慢买)")
        coupons = []
        source = "manmanbuy.com"
        url = "https://cu.manmanbuy.com/cx_0_0_jingdong_jx_New_1.aspx"

        html = self.fetch_with_js(url, wait_selector="li.item")
        if not html:
            self.log_scrape(source, "error", 0, "JS render failed")
            return coupons

        soup = BeautifulSoup(html, "html.parser")
        items = soup.select("li.item")
        logger.info(f"  Found {len(items)} items")

        for li in items:
            try:
                title = li.select_one("a.itemTitle")
                subtitle = li.select_one("a.itemSubTitle")
                img = li.select_one(".cover img")
                buy = li.select_one(".frinf .gobuy a[href]")
                mall = li.select_one(".frinf .mall")

                title_text = title.get_text(strip=True) if title else None
                discount_text = subtitle.get_text(strip=True) if subtitle else None
                img_url = img.get("src") if img else None
                local_img = self.download_image(img_url) if img_url else None
                coupon_url = buy.get("href").strip() if buy else None
                if coupon_url and coupon_url.startswith("/"):
                    coupon_url = f"https://cu.manmanbuy.com{coupon_url}"
                category = mall.get_text(strip=True) if mall else "JD.com"

                tags = [t.get_text(strip=True) for t in li.select(".fl.tag-box span")]
                desc = " | ".join(tags) if tags else None

                coupon = {
                    "source": source,
                    "title": title_text,
                    "description": desc,
                    "discount_amount": discount_text,
                    "discount_type": "deal",
                    "coupon_url": coupon_url,
                    "image_url": local_img,
                    "category": category,
                }
                self.save_coupon(coupon)
                coupons.append(coupon)
            except Exception as e:
                logger.warning(f"  Skipping item due to error: {e}")
                continue

        logger.info(f"  ✓ Saved {len(coupons)} Manmanbuy coupons")
        self.log_scrape(source, "success" if coupons else "error", len(coupons))
        return coupons


    # would love to add::
    # https://mtbfb.com/
    # https://www.shidehui.com/

    # -----------------------------------------
    # Query helpers for Flask app
    # -----------------------------------------
    def query_coupons(self, keyword: str = None, limit: int = 50) -> List[Dict]:
        """Query recent coupons, optionally filtered by keyword."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        if keyword:
            c.execute("""
                SELECT * FROM coupons
                WHERE title LIKE ? OR description LIKE ?
                ORDER BY scraped_at DESC
                LIMIT ?
            """, (f"%{keyword}%", f"%{keyword}%", limit))
        else:
            c.execute("""
                SELECT * FROM coupons
                ORDER BY scraped_at DESC
                LIMIT ?
            """, (limit,))
        rows = c.fetchall()
        conn.close()
        return [dict(row) for row in rows]


    # -----------------------------------------
    # All sources
    # -----------------------------------------
    def scrape_all(self):
        logger.info("============================================================")
        logger.info(f"Starting JD Coupon Scraper - {datetime.now()}")
        logger.info("============================================================")

        results = []
        results.extend(self.scrape_guangdiu())
        results.extend(self.scrape_quanlaoda())
        results.extend(self.scrape_manmanbuy())

        logger.info("============================================================")
        logger.info(f"Scraping completed! Total coupons found: {len(results)}")
        logger.info("============================================================")
        return results

