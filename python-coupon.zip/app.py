# app.py
# Flask app that runs scraper in background hourly and serves a UI

from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from scraper import JDCouponScraper
from apscheduler.schedulers.background import BackgroundScheduler
import os
import logging
logging.getLogger("werkzeug").setLevel(logging.WARNING)


# Configuration
CLEAR_DB_ON_START = False   # Set True the first time to clear / rebuild coupons table; set False after initial run if desired
SCRAPE_INTERVAL_MINUTES = 5  # every hour
DB_PATH = "jd_coupons.db"

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "dev-key-for-local")

# Instantiate scraper (it will create DB)
scraper = JDCouponScraper(db_path=DB_PATH, verify_ssl=False, clear_db=CLEAR_DB_ON_START)

# Background scheduler to run scraper periodically
scheduler = BackgroundScheduler()
scheduler.add_job(func=lambda: scheduled_scrape(), trigger="interval", minutes=SCRAPE_INTERVAL_MINUTES, next_run_time=None)
scheduler.start()

def scheduled_scrape():
    try:
        app.logger.info("Scheduled scrape started")
        scraped = scraper.scrape_all()
        app.logger.info(f"Scheduled scrape finished: {len(scraped)} items")
    except Exception as e:
        app.logger.exception("Scheduled scrape failed: %s", e)

@app.route("/", methods=["GET"])
def index():
    q = request.args.get("q", "").strip()
    limit = int(request.args.get("limit", 80))
    coupons = scraper.query_coupons(keyword=q, limit=limit)
    # coupons rows: id, source, title, description, discount_amount, coupon_url, image_url, category, updated_at
    return render_template("index.html", coupons=coupons, q=q)


@app.route("/scrape", methods=["POST"])
def manual_scrape():
    # Manual trigger endpoint
    try:
        scraped = scraper.scrape_all()
        flash(f"手动刮完: {len(scraped)} 项目", "success")
    except Exception as e:
        flash(f"手动抓取失败: {e}", "danger")
    return redirect(url_for("index"))

@app.route("/api/coupons", methods=["GET"])
def api_coupons():
    q = request.args.get("q", "").strip()
    limit = int(request.args.get("limit", 100))
    rows = scraper.query_coupons(keyword=q, limit=limit)
    data = []
    for r in rows:
        id_, source, title, description, discount_amount, coupon_url, image_url, category, updated_at = r
        data.append({
            "id": id_,
            "source": source,
            "title": title,
            "description": description,
            "discount_amount": discount_amount,
            "coupon_url": coupon_url,
            "image_url": image_url,
            "category": category,
            "updated_at": updated_at
        })
    return jsonify(data)

if __name__ == "__main__":
    # Run Flask dev server
    app.run(host="0.0.0.0", port=5001, debug=False)

