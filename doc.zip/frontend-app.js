import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FileText, Languages, ScanText, Upload, Download, Loader2, CheckCircle, XCircle } from 'lucide-react';
import './App.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function App() {
  const [activeTab, setActiveTab] = useState('convert');
  const [file, setFile] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [formats, setFormats] = useState(null);
  
  // Form states
  const [targetFormat, setTargetFormat] = useState('pdf');
  const [ocrLanguage, setOcrLanguage] = useState('eng');
  const [sourceLang, setSourceLang] = useState('auto');
  const [targetLang, setTargetLang] = useState('en');

  useEffect(() => {
    fetchFormats();
  }, []);

  const fetchFormats = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/formats`);
      setFormats(response.data);
    } catch (err) {
      console.error('Failed to fetch formats:', err);
    }
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    setResult(null);
    setError(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a file');
      return;
    }

    setProcessing(true);
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      let response;
      
      if (activeTab === 'convert') {
        formData.append('target_format', targetFormat);
        response = await axios.post(`${API_URL}/api/convert`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      } else if (activeTab === 'ocr') {
        formData.append('language', ocrLanguage);
        response = await axios.post(`${API_URL}/api/ocr`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      } else if (activeTab === 'translate') {
        formData.append('source_lang', sourceLang);
        formData.append('target_lang', targetLang);
        response = await axios.post(`${API_URL}/api/translate`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      }

      setResult(response.data);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'An error occurred');
    } finally {
      setProcessing(false);
    }
  };

  const renderTabContent = () => {
    if (activeTab === 'convert') {
      return (
        <div className="form-group">
          <label>Target Format</label>
          <select 
            value={targetFormat} 
            onChange={(e) => setTargetFormat(e.target.value)}
            className="select-input"
          >
            {formats?.conversion.map(fmt => (
              <option key={fmt} value={fmt}>{fmt.toUpperCase()}</option>
            ))}
          </select>
        </div>
      );
    } else if (activeTab === 'ocr') {
      return (
        <div className="form-group">
          <label>OCR Language</label>
          <select 
            value={ocrLanguage} 
            onChange={(e) => setOcrLanguage(e.target.value)}
            className="select-input"
          >
            {formats?.ocr_languages.map(lang => (
              <option key={lang} value={lang}>{lang}</option>
            ))}
          </select>
        </div>
      );
    } else if (activeTab === 'translate') {
      return (
        <>
          <div className="form-group">
            <label>Source Language</label>
            <select 
              value={sourceLang} 
              onChange={(e) => setSourceLang(e.target.value)}
              className="select-input"
            >
              <option value="auto">Auto-detect</option>
              {formats?.translation_languages.map(lang => (
                <option key={lang} value={lang}>{lang}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Target Language</label>
            <select 
              value={targetLang} 
              onChange={(e) => setTargetLang(e.target.value)}
              className="select-input"
            >
              {formats?.translation_languages.map(lang => (
                <option key={lang} value={lang}>{lang}</option>
              ))}
            </select>
          </div>
        </>
      );
    }
  };

  return (
    <div className="app">
      <header className="header">
        <div className="container">
          <h1 className="title">
            <FileText className="icon-large" />
            Document Processor
          </h1>
          <p className="subtitle">Convert, OCR, and Translate your documents</p>
        </div>
      </header>

      <main className="main">
        <div className="container">
          <div className="tabs">
            <button 
              className={`tab ${activeTab === 'convert' ? 'active' : ''}`}
              onClick={() => setActiveTab('convert')}
            >
              <FileText size={20} />
              Convert
            </button>
            <button 
              className={`tab ${activeTab === 'ocr' ? 'active' : ''}`}
              onClick={() => setActiveTab('ocr')}
            >
              <ScanText size={20} />
              OCR
            </button>
            <button 
              className={`tab ${activeTab === 'translate' ? 'active' : ''}`}
              onClick={() => setActiveTab('translate')}
            >
              <Languages size={20} />
              Translate
            </button>
          </div>

          <div className="card">
            <form onSubmit={handleSubmit}>
              <div className="file-upload">
                <input 
                  type="file" 
                  id="file-input"
                  onChange={handleFileChange}
                  className="file-input"
                />
                <label htmlFor="file-input" className="file-label">
                  <Upload size={24} />
                  {file ? file.name : 'Choose a file'}
                </label>
              </div>

              {formats && renderTabContent()}

              <button 
                type="submit" 
                className="submit-button"
                disabled={!file || processing}
              >
                {processing ? (
                  <>
                    <Loader2 className="spin" size={20} />
                    Processing...
                  </>
                ) : (
                  <>
                    Process Document
                  </>
                )}
              </button>
            </form>

            {error && (
              <div className="alert alert-error">
                <XCircle size={20} />
                {error}
              </div>
            )}

            {result && (
              <div className="alert alert-success">
                <CheckCircle size={20} />
                <div>
                  <p><strong>Success!</strong></p>
                  {result.filename && <p>File: {result.filename}</p>}
                  {result.text && (
                    <div className="text-preview">
                      <p><strong>Extracted Text:</strong></p>
                      <pre>{result.text.substring(0, 500)}...</pre>
                    </div>
                  )}
                  {result.translated_text && (
                    <div className="text-preview">
                      <p><strong>Translated Text:</strong></p>
                      <pre>{result.translated_text.substring(0, 500)}...</pre>
                    </div>
                  )}
                  {result.download_url && (
                    <a 
                      href={result.download_url} 
                      className="download-button"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Download size={18} />
                      Download Result
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="footer">
        <div className="container">
          <p>&copy; 2024 Document Processor. Powered by LibreOffice, Tesseract, and LibreTranslate.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;