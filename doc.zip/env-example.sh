# Aliyun OSS Configuration
OSS_ACCESS_KEY_ID=your_access_key_id_here
OSS_ACCESS_KEY_SECRET=your_access_key_secret_here
OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
OSS_BUCKET_NAME=your_bucket_name_here

# Example endpoints for different regions:
# oss-cn-hangzhou.aliyuncs.com (China East 1 - Hangzhou)
# oss-cn-shanghai.aliyuncs.com (China East 2 - Shanghai)
# oss-cn-beijing.aliyuncs.com (China North 2 - Beijing)
# oss-cn-shenzhen.aliyuncs.com (China South 1 - Shenzhen)
# oss-cn-hongkong.aliyuncs.com (Hong Kong)
# oss-ap-southeast-1.aliyuncs.com (Singapore)