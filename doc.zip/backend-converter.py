import os
import subprocess
from pathlib import Path
from PyPDF2 import PdfReader
from docx import Document
import logging

logger = logging.getLogger(__name__)

class DocumentConverter:
    """Handle document format conversions"""
    
    async def convert(self, input_path: str, target_format: str, original_filename: str) -> str:
        """Convert document to target format"""
        output_path = f"{input_path}_output.{target_format}"
        file_ext = Path(original_filename).suffix.lower()
        
        try:
            if target_format == "pdf":
                await self._convert_to_pdf(input_path, output_path, file_ext)
            elif target_format == "docx":
                await self._convert_to_docx(input_path, output_path, file_ext)
            elif target_format == "txt":
                await self._convert_to_txt(input_path, output_path, file_ext)
            elif target_format == "html":
                await self._convert_to_html(input_path, output_path, file_ext)
            elif target_format == "md":
                await self._convert_to_markdown(input_path, output_path, file_ext)
            else:
                raise ValueError(f"Unsupported target format: {target_format}")
            
            return output_path
        
        except Exception as e:
            logger.error(f"Conversion failed: {str(e)}")
            raise
    
    async def _convert_to_pdf(self, input_path: str, output_path: str, file_ext: str):
        """Convert to PDF using LibreOffice"""
        if file_ext == ".pdf":
            # Already PDF, just copy
            with open(input_path, 'rb') as f_in, open(output_path, 'wb') as f_out:
                f_out.write(f_in.read())
        else:
            # Use LibreOffice for conversion
            cmd = [
                "libreoffice",
                "--headless",
                "--convert-to", "pdf",
                "--outdir", os.path.dirname(output_path),
                input_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            
            # LibreOffice creates file with original name
            generated_file = input_path.replace(file_ext, ".pdf")
            if os.path.exists(generated_file):
                os.rename(generated_file, output_path)
    
    async def _convert_to_docx(self, input_path: str, output_path: str, file_ext: str):
        """Convert to DOCX"""
        if file_ext == ".docx":
            with open(input_path, 'rb') as f_in, open(output_path, 'wb') as f_out:
                f_out.write(f_in.read())
        else:
            cmd = [
                "libreoffice",
                "--headless",
                "--convert-to", "docx",
                "--outdir", os.path.dirname(output_path),
                input_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            
            generated_file = input_path.replace(file_ext, ".docx")
            if os.path.exists(generated_file):
                os.rename(generated_file, output_path)
    
    async def _convert_to_txt(self, input_path: str, output_path: str, file_ext: str):
        """Convert to plain text"""
        text = ""
        
        if file_ext == ".txt":
            with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                text = f.read()
        elif file_ext == ".pdf":
            reader = PdfReader(input_path)
            for page in reader.pages:
                text += page.extract_text() + "\n"
        elif file_ext == ".docx":
            doc = Document(input_path)
            text = "\n".join([para.text for para in doc.paragraphs])
        else:
            # Use LibreOffice as fallback
            temp_txt = input_path + "_temp.txt"
            cmd = [
                "libreoffice",
                "--headless",
                "--convert-to", "txt",
                "--outdir", os.path.dirname(temp_txt),
                input_path
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            
            generated_file = input_path.replace(file_ext, ".txt")
            if os.path.exists(generated_file):
                with open(generated_file, 'r', encoding='utf-8', errors='ignore') as f:
                    text = f.read()
                os.remove(generated_file)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(text)
    
    async def _convert_to_html(self, input_path: str, output_path: str, file_ext: str):
        """Convert to HTML"""
        cmd = [
            "libreoffice",
            "--headless",
            "--convert-to", "html",
            "--outdir", os.path.dirname(output_path),
            input_path
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        
        generated_file = input_path.replace(file_ext, ".html")
        if os.path.exists(generated_file):
            os.rename(generated_file, output_path)
    
    async def _convert_to_markdown(self, input_path: str, output_path: str, file_ext: str):
        """Convert to Markdown"""
        # First convert to HTML, then to Markdown
        temp_html = input_path + "_temp.html"
        await self._convert_to_html(input_path, temp_html, file_ext)
        
        # Simple HTML to Markdown conversion
        with open(temp_html, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        # Basic conversion (you may want to use a library like html2text for better results)
        import re
        md_content = html_content
        md_content = re.sub(r'<h1[^>]*>(.*?)</h1>', r'# \1\n', md_content)
        md_content = re.sub(r'<h2[^>]*>(.*?)</h2>', r'## \1\n', md_content)
        md_content = re.sub(r'<h3[^>]*>(.*?)</h3>', r'### \1\n', md_content)
        md_content = re.sub(r'<p[^>]*>(.*?)</p>', r'\1\n\n', md_content)
        md_content = re.sub(r'<strong[^>]*>(.*?)</strong>', r'**\1**', md_content)
        md_content = re.sub(r'<em[^>]*>(.*?)</em>', r'*\1*', md_content)
        md_content = re.sub(r'<[^>]+>', '', md_content)  # Remove remaining tags
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(md_content)
        
        os.remove(temp_html)