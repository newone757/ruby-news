# Document Processing Web App

A comprehensive web application for document conversion, OCR, and translation with Aliyun OSS storage backend.

## Features

- **Document Conversion**: Convert between PDF, DOCX, TXT, HTML, and Markdown formats
- **OCR**: Extract text from images and PDFs in multiple languages
- **Translation**: Translate documents using LibreTranslate
- **Cloud Storage**: Aliyun OSS integration for scalable file storage
- **Responsive UI**: Modern, mobile-friendly React interface

## Architecture

- **Frontend**: React with responsive design
- **Backend**: Python FastAPI
- **Storage**: Aliyun OSS (Object Storage Service)
- **OCR Engine**: Tesseract
- **Translation**: LibreTranslate
- **Deployment**: Docker Compose

## Prerequisites

- Docker and Docker Compose
- Aliyun OSS account and bucket
- At least 4GB RAM available for Docker

## Quick Start

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd document-processor
```

### 2. Configure Aliyun OSS

Create a `.env` file in the root directory:

```bash
cp .env.example .env
```

Edit `.env` and add your Aliyun OSS credentials:

```env
OSS_ACCESS_KEY_ID=your_access_key_id
OSS_ACCESS_KEY_SECRET=your_access_key_secret
OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
OSS_BUCKET_NAME=your_bucket_name
```

**To get your Aliyun OSS credentials:**

1. Log in to [Aliyun Console](https://console.aliyun.com)
2. Go to OSS service and create a bucket
3. Navigate to AccessKey management to get your keys
4. Choose the endpoint closest to your users

### 3. Project Structure

Create the following directory structure:

```
document-processor/
├── docker-compose.yml
├── .env
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py
│   └── services/
│       ├── __init__.py
│       ├── converter.py
│       ├── ocr.py
│       └── translator.py
└── frontend/
    ├── Dockerfile
    ├── nginx.conf
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js
        ├── App.css
        └── index.js
```

Create `backend/services/__init__.py`:
```python
# Empty file to make services a Python package
```

Create `frontend/public/index.html`:
```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#667eea" />
    <meta name="description" content="Document conversion, OCR, and translation" />
    <title>Document Processor</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
  </body>
</html>
```

Create `frontend/src/index.js`:
```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './App.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

### 4. Build and Run

```bash
# Build all services
docker-compose build

# Start all services
docker-compose up -d

# View logs
docker-compose logs -f
```

The application will be available at:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs

### 5. Stop Services

```bash
docker-compose down
```

## Usage

1. **Open the web interface** at http://localhost:3000
2. **Select a tab**:
   - Convert: Change document formats
   - OCR: Extract text from images/PDFs
   - Translate: Translate document content
3. **Upload a file** by clicking the upload area
4. **Configure options** (format, language, etc.)
5. **Click "Process Document"**
6. **Download the result** using the provided link

## Supported Formats

### Document Conversion
- Input: PDF, DOCX, TXT, HTML, MD
- Output: PDF, DOCX, TXT, HTML, MD

### OCR Languages
- English, Chinese (Simplified), Spanish, French, German, Japanese, Korean, Russian, Arabic

### Translation Languages
- English, Chinese, Spanish, French, German, Japanese, Korean, Russian, Arabic, Portuguese

## API Endpoints

### `POST /api/convert`
Convert document format
- **Parameters**: `file`, `target_format`
- **Returns**: Download URL for converted file

### `POST /api/ocr`
Extract text from images/PDFs
- **Parameters**: `file`, `language`
- **Returns**: Extracted text and download URL

### `POST /api/translate`
Translate document content
- **Parameters**: `file`, `source_lang`, `target_lang`
- **Returns**: Translated text and download URL

### `GET /api/formats`
Get supported formats and languages

## Configuration

### Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `OSS_ACCESS_KEY_ID` | Aliyun access key ID | `LTAI5t...` |
| `OSS_ACCESS_KEY_SECRET` | Aliyun access key secret | `xxx...` |
| `OSS_ENDPOINT` | OSS region endpoint | `oss-cn-hangzhou.aliyuncs.com` |
| `OSS_BUCKET_NAME` | OSS bucket name | `my-documents` |

### Aliyun OSS Regions

Choose the endpoint closest to your users:
- **China East 1**: `oss-cn-hangzhou.aliyuncs.com`
- **China East 2**: `oss-cn-shanghai.aliyuncs.com`
- **China North 2**: `oss-cn-beijing.aliyuncs.com`
- **Hong Kong**: `oss-cn-hongkong.aliyuncs.com`
- **Singapore**: `oss-ap-southeast-1.aliyuncs.com`

## Troubleshooting

### Backend fails to start
- Check that all environment variables are set correctly
- Verify Aliyun OSS credentials and bucket exist
- Check Docker logs: `docker-compose logs backend`

### OCR not working
- Ensure the file is an image or PDF
- Try a different language setting
- Check if the image quality is sufficient

### Translation fails
- LibreTranslate service may need time to load language models
- Check logs: `docker-compose logs libretranslate`
- Ensure source and target languages are different

### File upload errors
- Check file size (large files may timeout)
- Verify OSS bucket has write permissions
- Check backend logs for detailed error messages

## Performance Tips

1. **Aliyun OSS**: Use the endpoint closest to your users
2. **OCR**: Pre-process images (contrast, resolution) for better accuracy
3. **Translation**: Shorter texts translate faster; consider chunking large documents
4. **Docker**: Allocate at least 4GB RAM for optimal performance

## Security Notes

- Keep your `.env` file secure and never commit it to version control
- Use Aliyun RAM roles for production deployments
- Configure OSS bucket policies to restrict access
- Enable HTTPS in production (use a reverse proxy like Nginx)

## Production Deployment

For production, consider:

1. **Use environment-specific configs**
2. **Enable HTTPS** with Let's Encrypt
3. **Set up monitoring** and logging
4. **Configure resource limits** in docker-compose.yml
5. **Use Aliyun CDN** for faster file delivery
6. **Implement rate limiting** to prevent abuse
7. **Set up automated backups** of your OSS bucket

## License

MIT License - feel free to use this for your projects!

## Support

For issues or questions:
- Check the API documentation at http://localhost:8000/docs
- Review Docker logs: `docker-compose logs`
- Verify Aliyun OSS configuration in the console