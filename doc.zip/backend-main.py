from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import oss2
import os
import uuid
import tempfile
from typing import Optional
import aiohttp
from services.converter import DocumentConverter
from services.ocr import OCRService
from services.translator import TranslationService
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Document Processing API")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Aliyun OSS Configuration
OSS_ACCESS_KEY_ID = os.getenv("OSS_ACCESS_KEY_ID")
OSS_ACCESS_KEY_SECRET = os.getenv("OSS_ACCESS_KEY_SECRET")
OSS_ENDPOINT = os.getenv("OSS_ENDPOINT")
OSS_BUCKET_NAME = os.getenv("OSS_BUCKET_NAME")

# Initialize OSS bucket
auth = oss2.Auth(OSS_ACCESS_KEY_ID, OSS_ACCESS_KEY_SECRET)
bucket = oss2.Bucket(auth, OSS_ENDPOINT, OSS_BUCKET_NAME)

# Initialize services
converter = DocumentConverter()
ocr_service = OCRService()
translator = TranslationService(os.getenv("LIBRETRANSLATE_URL", "http://libretranslate:5000"))

@app.get("/")
async def root():
    return {"message": "Document Processing API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.post("/api/convert")
async def convert_document(
    file: UploadFile = File(...),
    target_format: str = Form(...)
):
    """Convert document to target format"""
    try:
        # Generate unique filename
        file_id = str(uuid.uuid4())
        original_filename = file.filename
        
        # Read file content
        content = await file.read()
        
        # Upload original to OSS
        oss_key = f"uploads/{file_id}/{original_filename}"
        bucket.put_object(oss_key, content)
        logger.info(f"Uploaded to OSS: {oss_key}")
        
        # Save to temp for processing
        temp_input = f"/app/temp/{file_id}_input"
        with open(temp_input, "wb") as f:
            f.write(content)
        
        # Convert document
        output_path = await converter.convert(temp_input, target_format, original_filename)
        
        # Read converted file
        with open(output_path, "rb") as f:
            converted_content = f.read()
        
        # Upload converted to OSS
        output_filename = f"{os.path.splitext(original_filename)[0]}.{target_format}"
        oss_output_key = f"converted/{file_id}/{output_filename}"
        bucket.put_object(oss_output_key, converted_content)
        
        # Cleanup
        os.remove(temp_input)
        os.remove(output_path)
        
        # Generate download URL (valid for 1 hour)
        download_url = bucket.sign_url('GET', oss_output_key, 3600)
        
        return {
            "success": True,
            "filename": output_filename,
            "download_url": download_url,
            "oss_key": oss_output_key
        }
    
    except Exception as e:
        logger.error(f"Conversion error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ocr")
async def perform_ocr(
    file: UploadFile = File(...),
    language: str = Form("eng")
):
    """Perform OCR on image or PDF"""
    try:
        file_id = str(uuid.uuid4())
        original_filename = file.filename
        
        # Read and upload to OSS
        content = await file.read()
        oss_key = f"uploads/{file_id}/{original_filename}"
        bucket.put_object(oss_key, content)
        
        # Save temp file
        temp_input = f"/app/temp/{file_id}_input"
        with open(temp_input, "wb") as f:
            f.write(content)
        
        # Perform OCR
        text = await ocr_service.extract_text(temp_input, language)
        
        # Save text to OSS
        text_filename = f"{os.path.splitext(original_filename)[0]}_ocr.txt"
        oss_text_key = f"ocr/{file_id}/{text_filename}"
        bucket.put_object(oss_text_key, text.encode('utf-8'))
        
        # Cleanup
        os.remove(temp_input)
        
        download_url = bucket.sign_url('GET', oss_text_key, 3600)
        
        return {
            "success": True,
            "text": text,
            "filename": text_filename,
            "download_url": download_url,
            "oss_key": oss_text_key
        }
    
    except Exception as e:
        logger.error(f"OCR error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/translate")
async def translate_document(
    file: UploadFile = File(...),
    source_lang: str = Form("auto"),
    target_lang: str = Form(...)
):
    """Translate document content"""
    try:
        file_id = str(uuid.uuid4())
        original_filename = file.filename
        
        # Read and upload to OSS
        content = await file.read()
        oss_key = f"uploads/{file_id}/{original_filename}"
        bucket.put_object(oss_key, content)
        
        # Extract text from document
        temp_input = f"/app/temp/{file_id}_input"
        with open(temp_input, "wb") as f:
            f.write(content)
        
        # Extract text based on file type
        text = await translator.extract_text_from_file(temp_input, original_filename)
        
        # Translate
        translated_text = await translator.translate(text, source_lang, target_lang)
        
        # Save translated text
        translated_filename = f"{os.path.splitext(original_filename)[0]}_{target_lang}.txt"
        oss_translated_key = f"translated/{file_id}/{translated_filename}"
        bucket.put_object(oss_translated_key, translated_text.encode('utf-8'))
        
        # Cleanup
        os.remove(temp_input)
        
        download_url = bucket.sign_url('GET', oss_translated_key, 3600)
        
        return {
            "success": True,
            "translated_text": translated_text,
            "filename": translated_filename,
            "download_url": download_url,
            "oss_key": oss_translated_key
        }
    
    except Exception as e:
        logger.error(f"Translation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/formats")
async def get_supported_formats():
    """Get supported conversion formats"""
    return {
        "conversion": ["pdf", "docx", "txt", "html", "md"],
        "ocr_languages": ["eng", "chi_sim", "spa", "fra", "deu", "jpn", "kor", "rus", "ara"],
        "translation_languages": ["en", "zh", "es", "fr", "de", "ja", "ko", "ru", "ar", "pt"]
    }