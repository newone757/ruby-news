import pytesseract
from PIL import Image
from pdf2image import convert_from_path
import os
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class OCRService:
    """Handle OCR operations"""
    
    async def extract_text(self, file_path: str, language: str = "eng") -> str:
        """Extract text from image or PDF"""
        file_ext = Path(file_path).suffix.lower()
        
        try:
            if file_ext in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
                return await self._ocr_image(file_path, language)
            elif file_ext == '.pdf':
                return await self._ocr_pdf(file_path, language)
            else:
                raise ValueError(f"Unsupported file type for OCR: {file_ext}")
        
        except Exception as e:
            logger.error(f"OCR failed: {str(e)}")
            raise
    
    async def _ocr_image(self, image_path: str, language: str) -> str:
        """Perform OCR on a single image"""
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang=language)
        return text
    
    async def _ocr_pdf(self, pdf_path: str, language: str) -> str:
        """Perform OCR on PDF (converts to images first)"""
        # Convert PDF to images
        images = convert_from_path(pdf_path)
        
        # Extract text from each page
        full_text = []
        for i, image in enumerate(images):
            logger.info(f"Processing page {i+1}/{len(images)}")
            text = pytesseract.image_to_string(image, lang=language)
            full_text.append(f"--- Page {i+1} ---\n{text}")
        
        return "\n\n".join(full_text)