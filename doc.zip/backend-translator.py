import aiohttp
from pathlib import Path
from PyPDF2 import PdfReader
from docx import Document
import logging

logger = logging.getLogger(__name__)

class TranslationService:
    """Handle translation operations"""
    
    def __init__(self, libretranslate_url: str):
        self.libretranslate_url = libretranslate_url
    
    async def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """Translate text using LibreTranslate"""
        # Split into chunks if text is too long (LibreTranslate has limits)
        max_length = 5000
        chunks = [text[i:i+max_length] for i in range(0, len(text), max_length)]
        
        translated_chunks = []
        async with aiohttp.ClientSession() as session:
            for chunk in chunks:
                payload = {
                    "q": chunk,
                    "source": source_lang,
                    "target": target_lang
                }
                
                async with session.post(
                    f"{self.libretranslate_url}/translate",
                    json=payload
                ) as response:
                    if response.status == 200:
                        result = await response.json()
                        translated_chunks.append(result["translatedText"])
                    else:
                        error_text = await response.text()
                        raise Exception(f"Translation failed: {error_text}")
        
        return "".join(translated_chunks)
    
    async def extract_text_from_file(self, file_path: str, filename: str) -> str:
        """Extract text from document for translation"""
        file_ext = Path(filename).suffix.lower()
        
        if file_ext == ".txt":
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        
        elif file_ext == ".pdf":
            reader = PdfReader(file_path)
            text = []
            for page in reader.pages:
                text.append(page.extract_text())
            return "\n".join(text)
        
        elif file_ext == ".docx":
            doc = Document(file_path)
            return "\n".join([para.text for para in doc.paragraphs])
        
        else:
            # Fallback: try reading as text
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()